export type AppView = 'landing' | 'login';

export type AuthMode = 'signup' | 'signin';

export interface AuthState {
  email: string;
  isLoading: boolean;
  isSubmitted: boolean;
  error: string | null;
}
