import React, { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { LandingPage } from './components/LandingPage';
import { LoginPage } from './components/LoginPage';
import { AppView, AuthMode } from './types';

export default function App() {
  const [view, setView] = useState<AppView>('landing');
  const [authMode, setAuthMode] = useState<AuthMode>('signup');

  const handleGetStarted = () => {
    setAuthMode('signup');
    setView('login');
  };

  const handleSignInClick = () => {
    setAuthMode('signin');
    setView('login');
  };

  const handleBackToLanding = () => {
    setView('landing');
  };

  return (
    <div className="min-h-screen w-full bg-slate-50 font-sans text-slate-900 overflow-x-hidden">
      <AnimatePresence mode="wait">
        {view === 'landing' ? (
          <motion.div
            key="landing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.3 }}
            className="w-full min-h-screen"
          >
            <LandingPage
              onGetStarted={handleGetStarted}
              onSignInClick={handleSignInClick}
            />
          </motion.div>
        ) : (
          <motion.div
            key="login"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            transition={{ duration: 0.3 }}
            className="w-full min-h-screen"
          >
            <LoginPage
              initialMode={authMode}
              onBack={handleBackToLanding}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
