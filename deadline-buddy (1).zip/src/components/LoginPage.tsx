import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, ArrowLeft, ArrowRight, CheckCircle2, ShieldCheck } from 'lucide-react';
import { BrandLogo } from './BrandLogo';
import { AuthMode } from '../types';

interface LoginPageProps {
  initialMode?: AuthMode;
  onBack: () => void;
  onAuthSuccess?: (email: string) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  initialMode = 'signup',
  onBack,
  onAuthSuccess,
}) => {
  const [mode, setMode] = useState<AuthMode>(initialMode);
  const [email, setEmail] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const validateEmail = (val: string) => {
    const trimmed = val.trim();
    if (!trimmed) {
      return 'Please enter your email address.';
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(trimmed)) {
      return 'Please enter a valid email address (e.g. name@university.edu).';
    }
    return null;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validationError = validateEmail(email);
    if (validationError) {
      setError(validationError);
      return;
    }

    setError(null);
    setIsLoading(true);

    // Prepare for authentication provider connection
    setTimeout(() => {
      setIsLoading(false);
      setIsSuccess(true);
      if (onAuthSuccess) {
        onAuthSuccess(email);
      }
    }, 600);
  };

  return (
    <div
      id="login-container"
      className="relative min-h-screen w-full flex flex-col justify-between bg-gradient-to-b from-slate-50 via-white to-slate-100/50 text-slate-800 selection:bg-indigo-100 selection:text-indigo-950"
    >
      {/* Top Header */}
      <header
        id="login-header"
        className="w-full max-w-5xl mx-auto px-6 py-6 flex items-center justify-between z-10"
      >
        <button
          id="login-back-btn"
          onClick={onBack}
          className="inline-flex items-center gap-2 text-sm font-medium text-slate-500 hover:text-slate-900 transition-colors py-2 px-3 -ml-3 rounded-lg hover:bg-slate-100/80 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>

        <BrandLogo size="sm" onClick={onBack} />
        
        {/* Visual balance placeholder */}
        <div className="w-16" />
      </header>

      {/* Main Form Center Card */}
      <main
        id="login-main-stage"
        className="flex-1 flex items-center justify-center px-6 py-8 z-10"
      >
        <motion.div
          id="login-card"
          initial={{ opacity: 0, y: 16, scale: 0.98 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="w-full max-w-md bg-white border border-slate-200/80 rounded-2xl shadow-xl shadow-slate-200/50 p-8 sm:p-10 relative overflow-hidden"
        >
          {/* Subtle top accent bar */}
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-indigo-500 to-indigo-600" />

          <AnimatePresence mode="wait">
            {!isSuccess ? (
              <motion.div
                key="form"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                {/* Header Titles */}
                <div className="text-center mb-8">
                  <div className="inline-flex items-center justify-center mb-3">
                    <BrandLogo size="md" showText={false} />
                  </div>

                  <h1
                    id="login-title"
                    className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight"
                  >
                    Welcome to Deadline Buddy
                  </h1>

                  <p
                    id="login-subtitle"
                    className="mt-2 text-sm sm:text-base text-slate-600 font-medium"
                  >
                    “Stay ahead of every deadline.”
                  </p>
                </div>

                {/* Form Section */}
                <form id="auth-form" onSubmit={handleSubmit} noValidate>
                  <div className="space-y-4">
                    <div>
                      <label
                        htmlFor="email-input"
                        className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2"
                      >
                        Email address
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                          <Mail className="w-5 h-5" />
                        </div>
                        <input
                          id="email-input"
                          type="email"
                          autoComplete="email"
                          required
                          value={email}
                          onChange={(e) => {
                            setEmail(e.target.value);
                            if (error) setError(null);
                          }}
                          placeholder="student@university.edu"
                          className={`w-full pl-11 pr-4 py-3 bg-slate-50 border rounded-xl text-slate-900 text-sm placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 transition-all ${
                            error
                              ? 'border-rose-400 focus:ring-rose-500/20 focus:border-rose-500'
                              : 'border-slate-200 focus:ring-indigo-500/20 focus:border-indigo-600'
                          }`}
                        />
                      </div>
                      {error && (
                        <p
                          id="email-error-message"
                          className="mt-2 text-xs font-medium text-rose-600"
                        >
                          {error}
                        </p>
                      )}
                    </div>

                    <button
                      id="continue-auth-btn"
                      type="submit"
                      disabled={isLoading}
                      className="w-full inline-flex items-center justify-center gap-2 py-3.5 px-4 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 disabled:opacity-70 text-white text-sm font-semibold rounded-xl shadow-md shadow-indigo-600/20 hover:shadow-indigo-600/30 transition-all cursor-pointer focus:outline-none focus:ring-4 focus:ring-indigo-500/25"
                    >
                      {isLoading ? (
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      ) : (
                        <>
                          <span>Continue</span>
                          <ArrowRight className="w-4 h-4" />
                        </>
                      )}
                    </button>
                  </div>
                </form>

                {/* Subtle option for existing users / new users toggle */}
                <div
                  id="auth-toggle-section"
                  className="mt-8 pt-6 border-t border-slate-100 text-center"
                >
                  {mode === 'signup' ? (
                    <p className="text-xs sm:text-sm text-slate-500">
                      Already have an account?{' '}
                      <button
                        id="toggle-to-signin-btn"
                        type="button"
                        onClick={() => {
                          setMode('signin');
                          setError(null);
                        }}
                        className="font-semibold text-indigo-600 hover:text-indigo-700 hover:underline focus:outline-none cursor-pointer"
                      >
                        Sign in
                      </button>
                    </p>
                  ) : (
                    <p className="text-xs sm:text-sm text-slate-500">
                      New to Deadline Buddy?{' '}
                      <button
                        id="toggle-to-signup-btn"
                        type="button"
                        onClick={() => {
                          setMode('signup');
                          setError(null);
                        }}
                        className="font-semibold text-indigo-600 hover:text-indigo-700 hover:underline focus:outline-none cursor-pointer"
                      >
                        Create an account
                      </button>
                    </p>
                  )}
                </div>

                {/* Safe Privacy Reassurance */}
                <div className="mt-6 flex items-center justify-center gap-1.5 text-[11px] text-slate-400">
                  <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
                  <span>Your academic schedules and privacy stay protected</span>
                </div>
              </motion.div>
            ) : (
              /* Success Confirmation / Prepared Auth State */
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4 }}
                className="text-center py-4"
              >
                <div className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-2xl mx-auto flex items-center justify-center mb-4 border border-emerald-100">
                  <CheckCircle2 className="w-8 h-8 text-emerald-600" />
                </div>

                <h2 className="text-xl font-bold text-slate-900">
                  Authentication Ready
                </h2>

                <p className="mt-2 text-sm text-slate-600">
                  Email set for <span className="font-semibold text-slate-900">{email}</span>.
                </p>

                <div className="my-6 p-4 rounded-xl bg-slate-50 border border-slate-200/80 text-left text-xs text-slate-600 space-y-1">
                  <div className="font-semibold text-slate-800">Next Step Architecture:</div>
                  <div>This login flow is structured to seamlessly plug into Firebase Auth, Supabase, or OAuth in upcoming steps.</div>
                </div>

                <div className="flex flex-col gap-2">
                  <button
                    onClick={() => {
                      setIsSuccess(false);
                    }}
                    className="w-full py-2.5 px-4 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
                  >
                    Edit Email or Switch Account
                  </button>

                  <button
                    onClick={onBack}
                    className="w-full py-2.5 px-4 rounded-xl text-xs font-medium text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
                  >
                    Return to Welcome Screen
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </main>

      {/* Footer */}
      <footer
        id="login-footer"
        className="w-full max-w-5xl mx-auto px-6 py-4 text-center text-xs text-slate-400 z-10"
      >
        <span>Deadline Buddy &middot; Designed to keep students ahead</span>
      </footer>
    </div>
  );
};
