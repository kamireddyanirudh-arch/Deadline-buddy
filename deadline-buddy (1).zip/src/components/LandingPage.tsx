import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Sparkles, CheckCircle2, Clock, Calendar } from 'lucide-react';
import { BrandLogo } from './BrandLogo';

interface LandingPageProps {
  onGetStarted: () => void;
  onSignInClick: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onGetStarted,
  onSignInClick,
}) => {
  return (
    <div
      id="landing-container"
      className="relative min-h-screen w-full flex flex-col justify-between bg-gradient-to-b from-slate-50 via-white to-indigo-50/30 overflow-hidden text-slate-800 selection:bg-indigo-100 selection:text-indigo-950"
    >
      {/* Subtle Background Geometric Ambience */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Soft radial focal glow */}
        <div className="absolute -top-36 left-1/2 -translate-x-1/2 w-[720px] h-[400px] bg-gradient-to-b from-indigo-100/60 to-transparent rounded-full blur-3xl opacity-70" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-purple-100/40 rounded-full blur-3xl" />
        <div className="absolute top-1/3 left-10 w-72 h-72 bg-sky-100/40 rounded-full blur-3xl" />

        {/* Delicate structural grid texture for academic clarity */}
        <div
          className="absolute inset-0 opacity-[0.025]"
          style={{
            backgroundImage: `radial-gradient(#1e293b 1px, transparent 1px)`,
            backgroundSize: '24px 24px',
          }}
        />
      </div>

      {/* Top Navigation Bar */}
      <header
        id="landing-header"
        className="relative z-10 w-full max-w-6xl mx-auto px-6 py-6 flex items-center justify-between"
      >
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        >
          <BrandLogo size="md" />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
          className="flex items-center gap-3"
        >
          <button
            id="header-signin-btn"
            onClick={onSignInClick}
            className="text-sm font-medium text-slate-600 hover:text-indigo-600 px-3.5 py-2 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
          >
            Sign in
          </button>
          <button
            id="header-get-started-btn"
            onClick={onGetStarted}
            className="text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 px-4 py-2 rounded-xl transition-all shadow-sm hover:shadow focus:outline-none focus:ring-2 focus:ring-slate-900 focus:ring-offset-2"
          >
            Get Started
          </button>
        </motion.div>
      </header>

      {/* Main Animated Stage */}
      <main
        id="landing-main-stage"
        className="relative z-10 flex-1 flex flex-col items-center justify-center px-6 py-12 text-center max-w-4xl mx-auto w-full"
      >
        {/* Step 1: Subtle Badge */}
        <motion.div
          id="landing-badge"
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-50/90 border border-indigo-100/80 text-indigo-700 text-xs font-semibold tracking-wide uppercase mb-8 shadow-xs"
        >
          <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
          <span>The Student Deadline Companion</span>
        </motion.div>

        {/* Step 2: The Core Quote */}
        <motion.div
          id="landing-quote-container"
          initial={{ opacity: 0, y: 22 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.45, ease: [0.16, 1, 0.3, 1] }}
          className="relative mb-10 max-w-2xl mx-auto"
        >
          <p
            id="landing-quote-text"
            className="font-serif italic text-2xl sm:text-3xl md:text-4xl text-slate-800 leading-relaxed font-normal tracking-normal"
          >
            “Every deadline becomes easier when you know what comes next.”
          </p>
        </motion.div>

        {/* Delicate divider between quote and branding */}
        <motion.div
          initial={{ scaleX: 0, opacity: 0 }}
          animate={{ scaleX: 1, opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.75, ease: [0.16, 1, 0.3, 1] }}
          className="w-16 h-px bg-slate-200 mb-8"
        />

        {/* Step 3: Brand Name & Tagline */}
        <motion.div
          id="landing-brand-block"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.9, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col items-center mb-10"
        >
          <h1
            id="landing-brand-title"
            className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-slate-900 tracking-tight mb-4"
          >
            Deadline <span className="text-indigo-600">Buddy</span>
          </h1>

          <p
            id="landing-tagline"
            className="text-lg sm:text-xl md:text-2xl text-slate-600 font-medium tracking-tight max-w-xl"
          >
            “Your deadlines. Your plan. Your peace of mind.”
          </p>
        </motion.div>

        {/* Step 4: Action Button */}
        <motion.div
          id="landing-cta-block"
          initial={{ opacity: 0, scale: 0.94, y: 14 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 1.25, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col sm:flex-row items-center gap-4"
        >
          <button
            id="get-started-main-btn"
            onClick={onGetStarted}
            className="group relative inline-flex items-center justify-center gap-3 px-8 py-4 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-base sm:text-lg font-semibold rounded-2xl shadow-lg shadow-indigo-600/20 hover:shadow-indigo-600/30 transition-all duration-200 hover:-translate-y-0.5 focus:outline-none focus:ring-4 focus:ring-indigo-500/25 cursor-pointer"
          >
            <span>Get Started</span>
            <ArrowRight className="w-5 h-5 transition-transform duration-200 group-hover:translate-x-1" />
          </button>

          <button
            id="landing-subtle-signin-btn"
            onClick={onSignInClick}
            className="px-6 py-4 text-slate-600 hover:text-slate-900 text-base font-medium rounded-2xl hover:bg-white/80 border border-transparent hover:border-slate-200 transition-all focus:outline-none focus:ring-2 focus:ring-slate-300 cursor-pointer"
          >
            Already have an account?
          </button>
        </motion.div>

        {/* Subtle reassuring highlights for student context */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 1.55 }}
          className="mt-14 grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-8 pt-8 border-t border-slate-200/60 max-w-xl w-full text-left"
        >
          <div className="flex items-center gap-2.5 text-xs text-slate-500">
            <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>Assignments & Exams</span>
          </div>
          <div className="flex items-center gap-2.5 text-xs text-slate-500">
            <Calendar className="w-4 h-4 text-indigo-500 shrink-0" />
            <span>Projects & Deadlines</span>
          </div>
          <div className="flex items-center gap-2.5 text-xs text-slate-500">
            <Clock className="w-4 h-4 text-amber-500 shrink-0" />
            <span>Smart Timeline Clarity</span>
          </div>
        </motion.div>
      </main>

      {/* Footer */}
      <footer
        id="landing-footer"
        className="relative z-10 w-full max-w-6xl mx-auto px-6 py-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400 border-t border-slate-200/50"
      >
        <div className="flex items-center gap-2">
          <span>&copy; {new Date().getFullYear()} Deadline Buddy</span>
          <span>&middot;</span>
          <span>Designed for students</span>
        </div>
        <div className="flex items-center gap-6">
          <span className="text-slate-500">Assignments &middot; Exams &middot; Applications &middot; Milestones</span>
        </div>
      </footer>
    </div>
  );
};
