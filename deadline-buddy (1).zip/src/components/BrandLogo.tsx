import React from 'react';

interface BrandLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  className?: string;
  onClick?: () => void;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  size = 'md',
  showText = true,
  className = '',
  onClick,
}) => {
  const iconDimensions = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-12 h-12',
    xl: 'w-16 h-16',
  };

  const textSizes = {
    sm: 'text-base font-semibold',
    md: 'text-lg font-bold',
    lg: 'text-2xl font-bold',
    xl: 'text-3xl font-extrabold',
  };

  const badgeDimensions = {
    sm: 'p-1.5 rounded-lg',
    md: 'p-2 rounded-xl',
    lg: 'p-2.5 rounded-2xl',
    xl: 'p-3.5 rounded-2xl',
  };

  return (
    <div
      id="brand-logo-container"
      onClick={onClick}
      className={`inline-flex items-center gap-2.5 select-none ${
        onClick ? 'cursor-pointer' : ''
      } ${className}`}
    >
      <div
        id="brand-logo-icon"
        className={`bg-indigo-600 text-white shadow-sm flex items-center justify-center relative overflow-hidden transition-transform duration-200 hover:scale-105 ${badgeDimensions[size]}`}
      >
        {/* Abstract Deadline + Companion Buddy icon */}
        <svg
          className={`${iconDimensions[size]} text-white`}
          viewBox="0 0 32 32"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Calendar milestone container */}
          <rect
            x="4"
            y="6"
            width="24"
            height="22"
            rx="5"
            stroke="currentColor"
            strokeWidth="2.2"
          />
          {/* Calendar top bar */}
          <path
            d="M4 12H28"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
          />
          {/* Calendar pins */}
          <path
            d="M9 4V7"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
          />
          <path
            d="M23 4V7"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
          />
          {/* Smooth check / forward progression path */}
          <path
            d="M10 20L14 24L22 16"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {/* Companion sparkle / Buddy dot */}
          <circle cx="21" cy="9.5" r="1.5" fill="#FDE047" />
        </svg>
      </div>

      {showText && (
        <span
          id="brand-logo-text"
          className={`tracking-tight text-slate-900 font-sans ${textSizes[size]}`}
        >
          Deadline <span className="text-indigo-600">Buddy</span>
        </span>
      )}
    </div>
  );
};
